package com.shehab.test;


import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {
    Spinner sp ;
    EditText amount;
    Button show;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
       sp = findViewById(R.id.spinner);
       amount = findViewById(R.id.ed);
       show = findViewById(R.id.button);
        ArrayList<Dataa> dataas = new ArrayList<>();
        dataas.add(new Dataa("Dollar",R.drawable.dollar));
        dataas.add(new Dataa("Euro",R.drawable.euro));
        dataas.add(new Dataa("Pound",R.drawable.euro));
        AdpterSPiner adpterSPiner = new AdpterSPiner(dataas,this);
        sp.setAdapter(adpterSPiner);
        sp.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                switch (i){
                    case 0:
                        show.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (amount.getText().toString().isEmpty()){
                                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT).show();
                                }else{
                                    String rate = String.valueOf(Double.parseDouble(amount.getText().toString())* 19.33121 + " USD");
                                    String Code = "USD";
                                    String desc = "united states dollar".toUpperCase();
                                    Intent i = new Intent(MainActivity.this,MainActivity2.class);
                                    i.putExtra("amountt",rate);
                                    i.putExtra("code",Code);
                                    i.putExtra("desc",desc);
                                    startActivity(i);
                                    amount.setText("");

                                }
                            }
                        });
                        break;
                    case 1:
                        show.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (amount.getText().toString().isEmpty()){
                                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT).show();
                                }else{
                                    String rate = String.valueOf(Double.parseDouble(amount.getText().toString())* 19.73342 + " Eruo");
                                    String Code = "Euro";
                                    String desc = "euro symbol".toUpperCase();
                                    Intent i = new Intent(MainActivity.this,MainActivity2.class);
                                    i.putExtra("amountt",rate);
                                    i.putExtra("code",Code);
                                    i.putExtra("desc",desc);
                                    startActivity(i);
                                    amount.setText("");

                                }

                            }
                        });
                        break;
                    case 2:
                        show.setOnClickListener(new View.OnClickListener() {
                            @Override
                            public void onClick(View view) {
                                if (amount.getText().toString().isEmpty()){
                                    Toast.makeText(MainActivity.this, "Error", Toast.LENGTH_SHORT).show();
                                }else{
                                    String rate = String.valueOf(Double.parseDouble(amount.getText().toString())* 17.35265 + " GBP");
                                    String Code = "GBP";
                                    String desc = "british pound sterling".toUpperCase();
                                    Intent i = new Intent(MainActivity.this,MainActivity2.class);
                                    i.putExtra("amountt",rate);
                                    i.putExtra("code",Code);
                                    i.putExtra("desc",desc);
                                    startActivity(i);
                                    amount.setText("");

                                }
                            }
                        });
                        break;
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });



    }

}