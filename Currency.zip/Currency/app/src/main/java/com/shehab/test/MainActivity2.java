package com.shehab.test;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    TextView cur,codee,descc;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        cur = findViewById(R.id.textCur);
        codee = findViewById(R.id.textCode);
        descc = findViewById(R.id.textdesc);

        String i = getIntent().getExtras().getString("amountt");
        String code = getIntent().getExtras().getString("code");
        String des = getIntent().getExtras().getString("desc");
        cur.setText("Rate: " + i);
        codee.setText("Code: " + code);
        descc.setText("Description: " + des);


    }
}